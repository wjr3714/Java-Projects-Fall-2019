Run the main method in ThreeDegrees.java located in the following directory: /src/edu/rit/cs/graph/ThreeDegrees.java

Test Cases and Validation of Test Cases are found in the report.txt and validation_report.txt files, respectively.